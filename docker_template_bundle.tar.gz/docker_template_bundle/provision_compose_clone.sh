#!/usr/bin/env bash
set -euo pipefail

TEMPLATE_VMID=${TEMPLATE_VMID:-9000}
SNIPPETS_DIR=${SNIPPETS_DIR:-/var/lib/vz/snippets}
SNIPPET_BASENAME=${SNIPPET_BASENAME:-app-inline-userdata.yaml}
STORAGE=${STORAGE:-local-lvm}

NEWID=${1:?Usage: $0 <new_vmid> <name> <pubkey> <app_name> [compose_url|-] [password|-]}
NEWNAME=${2:?}
PUBKEY=${3:?}
APP_NAME=${4:?}
COMPOSE_URL=${5:-"-"}
CIPASS=${6:-"BetterPassw0rd!"}

[[ -f "$PUBKEY" ]] || { echo "Key not found: $PUBKEY"; exit 1; }
[[ -f "$SNIPPETS_DIR/$SNIPPET_BASENAME" ]] || { echo "Snippet not found: $SNIPPETS_DIR/$SNIPPET_BASENAME"; exit 1; }

VM_SNIPPET="$SNIPPETS_DIR/${NEWNAME}-user-data.yaml"
cp "$SNIPPETS_DIR/$SNIPPET_BASENAME" "$VM_SNIPPET"
sed -i "s|\${APP_NAME}|${APP_NAME}|g" "$VM_SNIPPET"
sed -i "s|\${COMPOSE_URL}|${COMPOSE_URL}|g" "$VM_SNIPPET"

echo "[*] Cloning $TEMPLATE_VMID -> $NEWID ($NEWNAME)..."
qm clone "$TEMPLATE_VMID" "$NEWID" --name "$NEWNAME" --full

# qm resize "$NEWID" scsi0 40G

echo "[*] Set per-VM creds & SSH keys..."
if [[ "$CIPASS" != "-" ]]; then
  qm set "$NEWID" --ciuser dockeruser --cipassword "$CIPASS"
else
  qm set "$NEWID" --ciuser dockeruser
fi
qm set "$NEWID" --sshkey "$PUBKEY"

echo "[*] Bind user-data to this VM via cicustom..."
qm set "$NEWID" --cicustom "user=local:snippets/$(basename "$VM_SNIPPET")"

qm set "$NEWID" --name "$NEWNAME" --ipconfig0 ip=dhcp
qm cloudinit update "$NEWID"
qm start "$NEWID"

echo "[✓] $NEWNAME started."
